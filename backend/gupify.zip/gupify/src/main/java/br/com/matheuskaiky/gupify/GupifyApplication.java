package br.com.matheuskaiky.gupify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GupifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GupifyApplication.class, args);
	}

}
