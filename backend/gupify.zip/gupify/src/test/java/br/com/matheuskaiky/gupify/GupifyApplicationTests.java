package br.com.matheuskaiky.gupify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GupifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
